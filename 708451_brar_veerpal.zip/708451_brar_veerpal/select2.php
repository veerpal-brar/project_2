<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "library";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "<h3> LIBRARY_USER_MASTER:-</h3>";
$sql = "SELECT * FROM library_user_master";
$result = $conn->query($sql);



if ($result->num_rows > 0) {
    // output data of each row
    echo "<table border=1>
	<tr>
	<th>Id</th>
	<th>Password</th>
	<th>Date</th>
	
	</tr>";
    while($row = $result->fetch_assoc()) {
		
		echo "<tr>";
		echo "<td>" . $row['user_id'] . "</td>";
		echo "<td>" . $row['password'] . "</td>";
		echo "<td>" . $row['Account_creation_date'] . "</td>";
		
		echo "</tr>";
        //echo "<tr><td>". $row["id"] . "</td><td>" . $row["Name"] . "</td><td>" . $row["Address"]. "</td></tr>";
    }
    echo "</table><br><br><br>";
} else {
    echo "0 results";
}

// STUDENT_MASTER;
echo "<h3> STUDENT_MASTER:-</h3>";
$sql = "SELECT * FROM student_master";
$result = $conn->query($sql);



if ($result->num_rows > 0) {
    // output data of each row
    echo "<table border=1>
	<tr>
	<th>StudentId</th>
	<th>StudentName</th>
	<th>Gender</th>
		<th>Address</th>
			<th>City</th>
				<th>postalcode</th>
	
	</tr>";
    while($row = $result->fetch_assoc()) {
		
		echo "<tr>";
		echo "<td>" . $row['student_id'] . "</td>";
		echo "<td>" . $row['student_Name'] . "</td>";
		echo "<td>" . $row['Gender'] . "</td>";
		echo "<td>" . $row['Address'] . "</td>";
		echo "<td>" . $row['City'] . "</td>";
		echo "<td>" . $row['Postalcode'] . "</td>";
		
		echo "</tr>";
        //echo "<tr><td>". $row["id"] . "</td><td>" . $row["Name"] . "</td><td>" . $row["Address"]. "</td></tr>";
    }
    echo "</table><br><br><br>";
} else {
    echo "0 results";
}




$conn->close();
?>